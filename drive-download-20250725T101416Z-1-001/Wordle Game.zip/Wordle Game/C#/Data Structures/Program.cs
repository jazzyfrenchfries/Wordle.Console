﻿using System;
using System.Collections.Concurrent;
using System.Data;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
using DataStructures;

namespace DataStructures
{
    public class Stack{
        public int maxsize;
        public int[] numbers;
        public int top;

        public Stack(int size ){
            maxsize = size;
            numbers = new int [maxsize];
            top = -1;
        }
        public bool IsEmpty{
            get{
                return top == -1;
            }
        }
        public bool IsFull {
            get{
                return top == maxsize -1 ;
            }
        }

        public int Pop(){
           if (IsEmpty){
            return -1;
           } else{
            return numbers [top --];
           }
            }
        
        public void Push(int item){
            if(IsFull){
              return;

            } else{
                numbers [++ top ] = item;
                
            }
        }
        public int Peek(){
            if(IsEmpty){
                return 0;
            }else{
                return top;
                
            }
        
    }
    class Program
    {
        static void Main(string[] args)
        {
        Stack stack = new Stack(5);
        stack.Push(1);
        stack.Push(2);
        stack.Push(3);
        stack.Push(4);
        stack.Push(5);
        
        Console.WriteLine($"Is Stack full? > {stack.IsFull}");
        stack.Peek();
        Console.WriteLine($"Top of stack is {stack.Peek()}.");
        stack.Pop();
        Console.WriteLine($"Is stack full? > {stack.IsFull}");
    
        }
        }
}
}

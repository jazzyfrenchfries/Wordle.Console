﻿using System;
using System.Runtime.InteropServices;
using System.Security.AccessControl;




namespace PythonChallenges
{
    class Program
    {
        static void Main(string[] args)
        {
            int iOpt = 0;
            do
            {
                iOpt = Menu();
                switch (iOpt)
                {
                    case 0:
                        Console.WriteLine("Goodbye");
                        break;
                    case 1:
                        Challenge1();
                        break;
                    case 2:
                        Challenge2();
                        break;
                    case 3:
                        Challenge3();
                        break;
                    case 4:
                        Challenge4();
                        break;
                    case 5:
                        Challenge5();
                        break;
                    case 6:
                        Challenge6();
                        break;
                    case 7:
                        Challenge7();
                        break;
                    case 8:
                        Challenge8();
                        break;
                    case 9:
                        Challenge9();
                        break;
                    case 10:
                        Challenge10();
                        break;
 

                    case 20:
                        Challenge20();
                        break;
                    case 28:
                        Challenge28();
                        break;
                    default:
                        Console.WriteLine("Invalid option");
                        break;


                }
            } while (iOpt != 0);
        }
        static void Challenge1()
        {
            Console.WriteLine("Please enter your age");
            String age = Console.ReadLine();
            Console.WriteLine("Your age is:" + age);
        }


        static void Challenge2()
        {
            String outline;
            Console.Write("Enter Number 1>");
            Double n1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Number 2>");
            Double n2 = Convert.ToDouble(Console.ReadLine());
            Double avg = (n1 + n2) / 2;
            outline = $"The average of {n1} and {n2} is {avg}";
            Console.WriteLine(outline);


        }


        static void Challenge3()
        {
            String outline;
            Console.Write("Enter width >");
            Double wid = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter length >");
            Double len = Convert.ToDouble(Console.ReadLine());
            Double area = wid * len;
            outline =$"A rectangle of {wid} and {len} is {area}";
            Console.WriteLine(outline);
        }

        static void Challenge4(){
            String outline;
            Console.Write("Enter number 1 >");
            Double num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter number 2 >");
            Double num2 = Convert.ToDouble(Console.ReadLine());
            Double answer = num1 / num2 ; 
            outline = $"Dividing {num1} and {num2} is {answer}";
            Console.WriteLine(outline);

        }

        static void Challenge5(){

            String outline;
            Console.Write("Enter your name > ");
            String name = Convert.ToString(Console.ReadLine());
            Console.Write($"What is your favourite subject {name} ? ");
            String favSub = Convert.ToString(Console.ReadLine());
            outline = $"{favSub} is my favourite subject too! ";
            Console.WriteLine(outline);
        }

        static void Challenge6()
        {
            String name;
            Console.Write("Hi, what's your name>");
            name = Console.ReadLine();
            if (name == "James")
            {
                Console.WriteLine("You're cool!");
            }
            else
            {
                Console.WriteLine("Nice to meet you");
            }
        }
       
        static void Challenge7(){

            Int32 avTime; 
            Console.Write("How long on average do you watch tv per day? ");
            avTime =Convert.ToInt32( Console.ReadLine());
            if (avTime <= 2)
            {
                Console.WriteLine("That shouldn't rot your brain!");
            if (avTime == 4)
            {
                    Console.WriteLine("Aren't you getting square eyes?");

            }
            else {
                Console.WriteLine("Fresh air beats channel flicking");

            }
            }
        }

        static void Challenge8(){
            int Grade;
            Console.Write("What is your grade? > ");
            Grade = Convert.ToInt32(Console.ReadLine());
             
            if (Grade >= 75) {
                Console.WriteLine("Grade A");
            }
            else {
                if (Grade >= 60 ){
                    Console.WriteLine("Grade B");
                }

                else {
                    if (Grade >= 35){
                        Console.WriteLine ("Grade C");
                    }

                else {
                    if (Grade < 35){
                        Console.WriteLine("Grade D");
                    }
                }
                }
            }

            }
    
        

        static  void  Challenge9(){
            String OlympVal;
            Console.Write("Name an Olympic value > ");
            OlympVal = Console.ReadLine();
            switch (OlympVal.ToLower()){
              

            }
        }

        static void Challenge10(){
           
            }



        
        static void Challenge20()
        {
            int guess=-1, target=7;
            do
            {
                Console.Write("Guess Number>");
                guess = Convert.ToInt32(Console.ReadLine());
                if (guess == target)
                {
                    Console.WriteLine("Well done!");
                }
                else Console.WriteLine("Sorry wrong");


            } while (guess != target);
           
        }


        static void Challenge28()
        {
            Random rnum = new Random();
            String[] names = new String[5];
            String name;
            int x;
            bool cont = true;
            for (int n=0; n < 5; n++)
            {
                Console.Write("Enter name>");
                name = Console.ReadLine();
                names[n] = name;
            }
            do
            {
                x = rnum.Next(0, 5);
                Console.WriteLine($"name is {names[x]}");
                Console.Write("Another>");
                if (Console.ReadKey().Key != ConsoleKey.Y)
                {
                    cont = false;
                }
                else Console.WriteLine();
            } while (cont);


        }
       
        static int Menu()
        {
            String opt="";
            int rval=-1;
            Console.WriteLine("Menu");
            Console.WriteLine("--------------");
            Console.WriteLine(" 1) Challenge 1");
            Console.WriteLine(" 2) Challenge 2");
            Console.WriteLine(" 3) Challenge 3");
            Console.WriteLine(" 4) Challenge 4");
            Console.WriteLine(" 5) Challenge 5");
            Console.WriteLine(" 6) Challenge 6");
            Console.WriteLine(" 7) Challenge 7");
            Console.WriteLine(" 8) Challenge 8");
            Console.WriteLine(" 9) Challenge 9");
            Console.WriteLine(" 10) Challenge 10");
            Console.WriteLine(" 20) Challenge 20");
            Console.WriteLine(" 28) Challenge 28");
            Console.WriteLine(" Q) Quit");
            Console.WriteLine("");
            Console.Write("Enter Option>");
            opt = Console.ReadLine();
            if (opt=="q" || opt=="Q")
            {
                rval = 0;
            } else
            {
                try
                {
                    rval = Convert.ToInt32(opt);
                }
                catch
                {
                    rval = -1;
                }
               
            }
            return rval;


        }
    }
}
